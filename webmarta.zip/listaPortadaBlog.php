<?php
  include ('./claseDB.php');
  
 
    DB::listaPortadaBlog($leido);

?>