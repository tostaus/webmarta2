<?php
  include ('../claseDB.php');
 
  
      DB::ListaComentarioPen();
  
?>