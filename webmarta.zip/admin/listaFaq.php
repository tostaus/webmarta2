<?php
  include ('../claseDB.php');
  
  
    DB::listaFaq();

?>