<?php

phpinfo( );

?>
