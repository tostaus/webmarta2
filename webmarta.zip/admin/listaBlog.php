<?php
  include ('../claseDB.php');
  
  
    DB::listaBlog();

?>